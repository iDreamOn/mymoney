-- MySQL dump 10.14  Distrib 5.5.44-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: mymoney_development
-- ------------------------------------------------------
-- Server version	5.5.44-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `account_balances`
--

DROP TABLE IF EXISTS `account_balances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_balances` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `balance_date` date NOT NULL,
  `account_id` int(11) DEFAULT NULL,
  `amount` decimal(8,2) NOT NULL,
  `buffer` decimal(8,2) NOT NULL,
  `debt_id` int(11) DEFAULT NULL,
  `paid` tinyint(1) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `debt_balance_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_account_balances_on_account_id` (`account_id`),
  KEY `index_account_balances_on_debt_id` (`debt_id`),
  KEY `index_account_balances_on_debt_balance_id` (`debt_balance_id`),
  CONSTRAINT `fk_rails_bffc649d13` FOREIGN KEY (`debt_balance_id`) REFERENCES `debt_balances` (`id`),
  CONSTRAINT `fk_rails_8dd2e691a9` FOREIGN KEY (`debt_id`) REFERENCES `debts` (`id`),
  CONSTRAINT `fk_rails_f3e5781e9c` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_balances`
--

LOCK TABLES `account_balances` WRITE;
/*!40000 ALTER TABLE `account_balances` DISABLE KEYS */;
INSERT INTO `account_balances` VALUES (3,'2015-10-30',2,2103.00,10.00,1,0,'2015-12-19 21:44:56','2016-01-19 21:37:06',5),(4,'2015-10-16',2,1864.00,10.00,1,0,'2015-12-19 21:44:56','2016-01-19 21:36:03',5),(5,'2015-11-06',2,1085.00,10.00,1,0,'2015-12-19 21:44:56','2016-01-19 21:37:06',5),(6,'2015-10-23',2,436.00,10.00,1,0,'2015-12-19 21:44:56','2016-01-19 21:37:06',5),(7,'2015-12-04',2,4934.00,10.00,2,1,'2015-12-19 21:44:56','2016-01-19 21:37:06',2),(8,'2015-12-04',1,2000.00,10.00,2,1,'2015-12-19 21:44:56','2016-01-19 21:37:06',2),(9,'2015-11-28',1,1010.00,10.00,2,0,'2015-12-19 21:44:56','2016-01-19 21:37:06',2),(10,'2015-10-16',1,710.00,10.00,2,0,'2015-12-19 21:44:56','2016-01-19 21:37:06',2),(11,'2015-11-06',1,80.00,10.00,2,0,'2015-12-19 21:44:56','2016-01-19 21:37:06',2),(18,'2015-12-31',2,2130.00,10.00,13,0,'2015-12-23 05:38:55','2016-01-20 07:03:03',16),(19,'2016-01-01',5,1250.00,10.00,12,0,'2015-12-25 09:03:00','2016-01-20 06:36:04',16),(20,'2016-01-01',1,3524.00,10.00,1,0,'2015-12-26 06:10:12','2016-01-20 06:36:17',2);
/*!40000 ALTER TABLE `account_balances` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `accounts`
--

DROP TABLE IF EXISTS `accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `name` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `account_type` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `by_user_name` (`user_id`,`name`),
  KEY `index_accounts_on_user_id` (`user_id`),
  CONSTRAINT `fk_rails_b1e30bebc8` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounts`
--

LOCK TABLES `accounts` WRITE;
/*!40000 ALTER TABLE `accounts` DISABLE KEYS */;
INSERT INTO `accounts` VALUES (1,2,'Chase','Checkings','2015-12-19 13:23:49','2015-12-19 13:27:54'),(2,2,'Bank Of America','Checkings','2015-12-19 18:53:28','2015-12-19 23:19:20'),(5,3,'Bank of America','Checking','2015-12-25 05:10:32','2015-12-25 05:10:32');
/*!40000 ALTER TABLE `accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `budgets`
--

DROP TABLE IF EXISTS `budgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `budgets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) DEFAULT NULL,
  `budget_month` date NOT NULL,
  `amount` decimal(8,2) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `by_category_month` (`category_id`,`budget_month`),
  KEY `index_budgets_on_category_id` (`category_id`),
  CONSTRAINT `fk_rails_a52bce3297` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=176 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `budgets`
--

LOCK TABLES `budgets` WRITE;
/*!40000 ALTER TABLE `budgets` DISABLE KEYS */;
INSERT INTO `budgets` VALUES (1,1,'2015-06-01',508.47,'2015-09-04 13:30:57','2015-09-04 13:30:57'),(2,2,'2015-06-01',120.96,'2015-09-04 13:30:57','2015-09-04 13:30:57'),(3,3,'2015-06-01',21.33,'2015-09-04 13:30:57','2015-09-04 13:30:57'),(4,4,'2015-06-01',271.92,'2015-09-04 13:30:57','2015-09-04 13:30:57'),(5,5,'2015-06-01',87.80,'2015-09-04 13:30:57','2015-09-04 13:30:57'),(6,1,'2015-07-01',489.44,'2015-09-04 13:30:57','2015-09-04 13:30:57'),(7,2,'2015-07-01',103.14,'2015-09-04 13:30:57','2015-09-04 13:30:57'),(8,3,'2015-07-01',168.02,'2015-09-04 13:30:57','2015-09-04 13:30:57'),(9,4,'2015-07-01',272.79,'2015-09-04 13:30:57','2015-09-04 13:30:57'),(10,5,'2015-07-01',191.83,'2015-09-04 13:30:57','2015-09-04 13:30:57'),(11,1,'2015-08-01',391.66,'2015-09-04 13:30:57','2015-09-04 13:30:57'),(12,2,'2015-08-01',153.62,'2015-09-04 13:30:57','2015-09-04 13:30:57'),(13,3,'2015-08-01',184.22,'2015-09-04 13:30:57','2015-09-04 13:30:57'),(14,4,'2015-08-01',262.43,'2015-09-04 13:30:57','2015-09-04 13:30:57'),(15,5,'2015-08-01',150.10,'2015-09-04 13:30:57','2015-09-04 13:30:57'),(16,1,'2015-09-01',339.62,'2015-09-04 13:30:57','2015-09-04 13:30:57'),(17,2,'2015-09-01',136.04,'2015-09-04 13:30:57','2015-09-04 13:30:57'),(18,3,'2015-09-01',193.34,'2015-09-04 13:30:57','2015-09-04 13:30:57'),(19,4,'2015-09-01',277.60,'2015-09-04 13:30:57','2015-09-04 13:30:57'),(20,5,'2015-09-01',152.07,'2015-09-04 13:30:57','2015-09-04 13:30:57'),(21,6,'2015-06-01',0.00,'2015-09-26 02:31:05','2015-09-26 02:31:05'),(22,6,'2015-07-01',0.00,'2015-09-26 02:31:05','2015-09-26 02:31:05'),(23,6,'2015-08-01',0.00,'2015-09-26 02:31:05','2015-09-26 02:31:05'),(24,6,'2015-09-01',850.00,'2015-09-26 02:31:05','2015-09-26 02:31:39'),(144,1,'2015-10-01',298.97,'2015-10-21 16:39:41','2015-10-21 16:39:41'),(145,2,'2015-10-01',162.68,'2015-10-21 16:39:41','2015-10-21 16:39:41'),(146,3,'2015-10-01',166.95,'2015-10-21 16:39:41','2015-10-21 16:39:41'),(147,4,'2015-10-01',283.90,'2015-10-21 16:39:41','2015-10-21 16:39:41'),(148,5,'2015-10-01',130.32,'2015-10-21 16:39:41','2015-10-21 16:39:41'),(149,6,'2015-10-01',328.00,'2015-10-21 16:39:41','2015-10-21 16:39:41'),(150,1,'2015-11-01',298.97,'2015-11-14 12:51:20','2015-11-14 12:51:20'),(151,2,'2015-11-01',162.68,'2015-11-14 12:51:20','2015-11-14 12:51:20'),(152,3,'2015-11-01',166.95,'2015-11-14 12:51:20','2015-11-14 12:51:20'),(153,4,'2015-11-01',283.90,'2015-11-14 12:51:20','2015-11-14 12:51:20'),(154,5,'2015-11-01',130.32,'2015-11-14 12:51:20','2015-11-14 12:51:20'),(155,6,'2015-11-01',328.00,'2015-11-14 12:51:20','2015-11-14 12:51:20'),(156,7,'2015-06-01',0.00,'2015-11-28 05:04:41','2015-11-28 05:04:41'),(157,7,'2015-07-01',0.00,'2015-11-28 05:04:41','2015-11-28 05:04:41'),(158,7,'2015-08-01',0.00,'2015-11-28 05:04:41','2015-11-28 05:04:41'),(159,7,'2015-09-01',0.00,'2015-11-28 05:04:41','2015-11-28 05:04:41'),(160,7,'2015-10-01',0.00,'2015-11-28 05:04:41','2015-11-28 05:04:41'),(161,7,'2015-11-01',0.00,'2015-11-28 05:04:41','2015-11-28 05:04:41'),(170,11,'2015-12-01',100.00,'2015-12-25 10:18:51','2015-12-26 02:07:14'),(171,5,'2015-12-01',0.00,'2015-12-25 10:24:19','2015-12-25 10:24:19'),(172,1,'2015-12-01',2340.00,'2015-12-26 02:19:51','2015-12-26 02:19:51'),(173,2,'2015-12-01',0.00,'2015-12-26 02:23:13','2015-12-26 02:23:13'),(174,4,'2016-01-01',100.00,'2016-01-20 00:54:41','2016-01-20 00:54:41'),(175,10,'2016-01-01',1234.00,'2016-01-20 01:03:32','2016-01-20 01:03:32');
/*!40000 ALTER TABLE `budgets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `by_user_name` (`user_id`,`name`),
  KEY `index_categories_on_user_id` (`user_id`),
  CONSTRAINT `fk_rails_b8e2f7adfc` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'Automotive, Home & Games','Awesome Silk Bench','2015-09-04 17:29:54','2015-09-04 17:29:54',2),(2,'Beauty, Music & Automotive','Ergonomic Paper Bench','2015-09-04 17:29:54','2015-09-04 17:29:54',2),(3,'Garden, Health, Books, Industrial & Home','Durable Iron Clock','2015-09-04 17:29:54','2015-09-04 17:29:54',2),(4,'Loans','All loans','2015-09-04 17:29:54','2015-09-04 17:29:54',2),(5,'Credit Cards','Credit Card Payment','2015-09-04 17:29:54','2015-09-04 17:29:54',2),(6,'Savings','all savings','2015-09-26 02:31:05','2015-09-26 02:31:05',2),(7,'Rent','Rent','2015-11-28 05:04:41','2015-11-28 05:04:41',2),(9,'Bill','All loans','2015-12-25 05:33:44','2015-12-25 05:33:44',3),(10,'Loans','All loans','2015-12-25 05:42:59','2015-12-25 05:42:59',3),(11,'Credit Cards','Credit Card Payments','2015-12-25 09:26:54','2015-12-25 09:26:54',3);
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `debt_balances`
--

DROP TABLE IF EXISTS `debt_balances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `debt_balances` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `debt_id` int(11) DEFAULT NULL,
  `due_date` date NOT NULL,
  `balance` decimal(10,2) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `payment_start_date` date DEFAULT NULL,
  `target_balance` decimal(10,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `by_debt_due_date` (`debt_id`,`due_date`),
  KEY `index_debt_balances_on_debt_id` (`debt_id`),
  KEY `index_debt_balances_on_payment_start_date` (`payment_start_date`),
  CONSTRAINT `fk_rails_018983ce3e` FOREIGN KEY (`debt_id`) REFERENCES `debts` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `debt_balances`
--

LOCK TABLES `debt_balances` WRITE;
/*!40000 ALTER TABLE `debt_balances` DISABLE KEYS */;
INSERT INTO `debt_balances` VALUES (1,1,'2015-09-15',1000.00,'2015-09-04 18:39:29','2015-12-01 02:42:52','2015-08-16',0.00),(2,2,'2019-01-01',4400.00,'2015-09-04 19:14:36','2015-11-30 12:53:59','2015-04-01',0.00),(3,1,'2015-08-15',500.00,'2015-09-04 19:16:17','2015-12-01 02:43:06','2015-07-16',0.00),(4,1,'2015-10-15',1000.00,'2015-09-04 19:19:29','2015-12-01 02:42:37','2015-09-16',0.00),(5,1,'2015-11-15',500.00,'2015-09-04 19:19:53','2015-10-15 16:30:38','2015-10-16',0.00),(6,1,'2015-01-15',3020.12,'2015-09-04 21:12:17','2015-12-01 02:44:47','2014-12-16',0.00),(7,1,'2015-02-15',2021.96,'2015-09-04 21:12:17','2015-12-01 02:44:27','2015-01-16',0.00),(8,1,'2015-03-15',2156.72,'2015-09-04 21:12:17','2015-12-01 02:44:17','2015-02-16',0.00),(9,1,'2015-04-15',2524.68,'2015-09-04 21:12:17','2015-12-01 02:44:02','2015-03-16',0.00),(10,1,'2015-05-15',2779.96,'2015-09-04 21:12:17','2015-12-01 02:43:50','2015-04-16',0.00),(11,1,'2015-06-15',3447.21,'2015-09-04 21:12:17','2015-12-01 02:43:34','2015-05-16',0.00),(12,1,'2015-07-15',3852.46,'2015-09-04 21:12:17','2015-12-01 02:43:21','2015-06-16',0.00),(13,4,'2018-12-01',14000.00,'2015-10-15 16:58:27','2015-10-15 16:58:27','2014-06-01',0.00),(14,8,'2017-02-01',26350.00,'2015-11-27 21:06:13','2015-11-27 21:11:40','2015-10-01',0.00),(15,1,'2015-12-15',4325.00,'2015-12-06 02:30:15','2015-12-06 02:30:15','2015-11-16',0.00),(16,12,'2016-12-31',1000.00,'2015-12-25 08:55:43','2015-12-25 08:55:43','2015-01-01',0.00),(17,13,'2015-12-29',2345.00,'2015-12-25 09:28:33','2015-12-25 09:28:33','2015-11-30',0.00);
/*!40000 ALTER TABLE `debt_balances` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `debts`
--

DROP TABLE IF EXISTS `debts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `debts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sub_category` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `is_asset` tinyint(1) DEFAULT '0',
  `deleted_at` datetime DEFAULT NULL,
  `fix_amount` decimal(10,2) DEFAULT NULL,
  `schedule` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `payment_start_date` date DEFAULT NULL,
  `autopay` tinyint(1) DEFAULT '0',
  `category_id` int(11) DEFAULT NULL,
  `account_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `by_category_name` (`name`,`deleted_at`),
  KEY `index_debts_on_deleted_at` (`deleted_at`),
  KEY `index_debts_on_category_id` (`category_id`),
  KEY `index_debts_on_account_id` (`account_id`),
  CONSTRAINT `fk_rails_70121aec5f` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`),
  CONSTRAINT `fk_rails_7a39d3469e` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `debts`
--

LOCK TABLES `debts` WRITE;
/*!40000 ALTER TABLE `debts` DISABLE KEYS */;
INSERT INTO `debts` VALUES (1,'Credit Cards','Amex','2015-09-04 17:29:53','2015-12-19 15:01:04',0,NULL,NULL,'Bi-Weekly',NULL,0,5,2),(2,'Student Loans','WolffAcademy','2015-09-04 17:29:54','2016-01-20 06:32:18',0,NULL,NULL,'Bi-Weekly',NULL,1,4,1),(4,'Car Loans','Vw','2015-10-15 16:46:51','2015-11-27 20:25:00',0,NULL,186.19,'Bi-Weekly','2015-09-11',1,4,2),(7,'Savings','Emergency Fundings','2015-11-26 21:38:19','2015-11-26 21:38:19',1,NULL,NULL,NULL,NULL,0,6,2),(8,'Rent','Avalon','2015-11-27 21:02:29','2015-12-24 17:21:22',0,NULL,1550.00,'Monthly',NULL,0,7,2),(9,'Phone','Sams Phone','2015-12-05 18:39:57','2015-12-05 18:39:57',0,NULL,NULL,'Bi-Weekly',NULL,0,4,2),(12,'Test','Test','2015-12-25 08:29:01','2015-12-25 08:29:01',0,NULL,NULL,'Bi-Weekly',NULL,1,10,5),(13,'Test','City','2015-12-25 09:27:52','2015-12-25 09:27:52',0,NULL,NULL,'Bi-Weekly',NULL,0,11,5);
/*!40000 ALTER TABLE `debts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `income_distributions`
--

DROP TABLE IF EXISTS `income_distributions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `income_distributions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `distribution_date` date DEFAULT NULL,
  `boa_chk` decimal(8,2) NOT NULL,
  `chase_chk` decimal(8,2) NOT NULL,
  `paid` tinyint(1) DEFAULT '0',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `chase_focus` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `boa_focus` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_income_distributions_on_distribution_date` (`distribution_date`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `income_distributions`
--

LOCK TABLES `income_distributions` WRITE;
/*!40000 ALTER TABLE `income_distributions` DISABLE KEYS */;
INSERT INTO `income_distributions` VALUES (4,'2015-10-23',436.19,10.00,0,'2015-10-15 18:11:26','2015-11-02 14:26:48','Chase','Amex'),(5,'2015-11-06',1085.00,80.00,0,'2015-10-15 19:16:31','2015-11-28 03:26:45','Wolff Academy','Amex'),(6,'2015-10-16',1863.88,710.00,0,'2015-10-17 17:32:02','2015-11-19 20:36:40','Wolff Academy','Amex'),(7,'2015-10-30',2103.00,10.00,0,'2015-10-17 17:40:20','2015-11-28 16:13:09','Wolff Academy','Amex'),(8,'2015-11-28',2600.00,1010.00,0,'2015-11-28 16:14:44','2015-11-28 16:15:10','Wolff Academy','Bank Of America'),(9,'2015-12-04',2934.00,2000.00,1,'2015-11-29 16:36:08','2015-12-04 16:29:51','Wolff Academy','Wolff Academy');
/*!40000 ALTER TABLE `income_distributions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `income_sources`
--

DROP TABLE IF EXISTS `income_sources`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `income_sources` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `pay_schedule` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `pay_day` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `amount` decimal(8,2) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `account_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_income_sources_on_account_id` (`account_id`),
  CONSTRAINT `fk_rails_e50d816235` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `income_sources`
--

LOCK TABLES `income_sources` WRITE;
/*!40000 ALTER TABLE `income_sources` DISABLE KEYS */;
INSERT INTO `income_sources` VALUES (1,'Job 3','bi-weekly','friday',100.00,'2015-06-05','2015-08-31','2015-12-13 19:43:15','2015-12-19 14:16:13',1),(2,'Job 2','semi-monthly','15, last',100.00,'2015-10-01','2015-12-31','2015-12-13 22:10:29','2015-12-19 14:14:49',1),(3,'Job 1','weekly','thursday',100.00,'2015-01-01','2015-12-31','2015-12-14 00:41:21','2015-12-19 14:16:05',1),(4,'Job 3b','weekly','friday',150.00,'2015-12-04','2016-01-01','2015-12-25 07:01:55','2015-12-25 07:01:55',5);
/*!40000 ALTER TABLE `income_sources` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_methods`
--

DROP TABLE IF EXISTS `payment_methods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment_methods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `by_user_name` (`user_id`,`name`),
  KEY `index_payment_methods_on_user_id` (`user_id`),
  CONSTRAINT `fk_rails_e13d4c515f` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_methods`
--

LOCK TABLES `payment_methods` WRITE;
/*!40000 ALTER TABLE `payment_methods` DISABLE KEYS */;
INSERT INTO `payment_methods` VALUES (1,'Credit','Any of our cc','2015-09-04 17:29:53','2015-09-04 17:29:53',2),(2,'Debit','Any of our debit','2015-09-04 17:29:53','2015-09-04 17:29:53',2),(3,'Gift','Any gift card','2015-09-04 17:29:53','2015-09-04 17:29:53',2),(4,'Cash','Cash','2015-09-04 17:29:53','2015-09-04 17:29:53',2),(5,'Other','Any other form of payments','2015-09-04 17:29:53','2015-09-04 17:29:53',2),(6,'Credit','All Credit purchases','2015-12-25 05:47:53','2015-12-25 05:47:53',3),(7,'Paypal','Must have a payment method','2016-01-20 16:30:02','2016-01-20 16:30:02',2);
/*!40000 ALTER TABLE `payment_methods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schema_migrations`
--

DROP TABLE IF EXISTS `schema_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schema_migrations` (
  `version` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  UNIQUE KEY `unique_schema_migrations` (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schema_migrations`
--

LOCK TABLES `schema_migrations` WRITE;
/*!40000 ALTER TABLE `schema_migrations` DISABLE KEYS */;
INSERT INTO `schema_migrations` VALUES ('20150705142415'),('20150705142815'),('20150824134412'),('20150826134546'),('20150826205503'),('20150901174002'),('20150901174504'),('20150904153448'),('20150904175601'),('20150912200636'),('20150914213216'),('20150919031028'),('20151126202850'),('20151126210827'),('20151127193950'),('20151213155744'),('20151213155844'),('20151219134423'),('20151219142505'),('20151219144201'),('20151219153456'),('20151219173757'),('20151219174323'),('20151219210248'),('20151219231022'),('20151219234122'),('20151225050544'),('20151225051450'),('20151225072921'),('20151225074548'),('20151225080828'),('20151225123843'),('20160112124221'),('20160119212117'),('20160120145443');
/*!40000 ALTER TABLE `schema_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `spendings`
--

DROP TABLE IF EXISTS `spendings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `spendings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `spending_date` date NOT NULL,
  `amount` decimal(8,2) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `budget_id` int(11) DEFAULT NULL,
  `payment_method_id` int(11) DEFAULT NULL,
  `debt_balance_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_spendings_on_spending_date` (`spending_date`),
  KEY `index_spendings_on_budget_id` (`budget_id`),
  KEY `index_spendings_on_payment_method_id` (`payment_method_id`),
  KEY `index_spendings_on_debt_balance_id` (`debt_balance_id`),
  CONSTRAINT `fk_rails_089b4a7901` FOREIGN KEY (`debt_balance_id`) REFERENCES `debt_balances` (`id`),
  CONSTRAINT `fk_rails_2473d18826` FOREIGN KEY (`payment_method_id`) REFERENCES `payment_methods` (`id`),
  CONSTRAINT `fk_rails_4aac1c2679` FOREIGN KEY (`budget_id`) REFERENCES `budgets` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=137 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `spendings`
--

LOCK TABLES `spendings` WRITE;
/*!40000 ALTER TABLE `spendings` DISABLE KEYS */;
INSERT INTO `spendings` VALUES (1,'Wolff Academy','2015-05-08',92.44,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,2,2),(2,'Awesome Granite Pants','2015-05-23',55.79,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,4,NULL),(3,'Amex','2015-06-12',92.20,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,2,11),(4,'Gorgeous Concrete Clock','2015-09-08',32.32,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,2,NULL),(5,'Sleek Granite Lamp','2015-05-01',34.70,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,3,NULL),(6,'Amex','2015-09-25',22.60,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,2,4),(7,'Amex','2015-06-23',23.95,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,2,12),(8,'Practical Granite Coat','2015-09-24',54.61,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,4,NULL),(9,'Incredible Aluminum Coat','2015-05-04',24.66,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,1,NULL),(10,'Enormous Bronze Shoes','2015-09-03',15.41,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,3,NULL),(11,'Amex','2015-06-25',85.88,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,2,12),(12,'Wolff Academy','2015-06-16',83.51,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,2,2),(13,'Gorgeous Steel Table','2015-07-14',80.56,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,3,NULL),(14,'Synergistic Rubber Coat','2015-07-08',60.65,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,2,NULL),(15,'Heavy Duty Plastic Plate','2015-09-19',94.74,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,4,NULL),(16,'Incredible Leather Clock','2015-06-25',9.72,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,4,NULL),(17,'Awesome Plastic Plate','2015-08-13',56.06,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,2,NULL),(18,'Wolff Academy','2015-08-31',74.84,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,2,2),(19,'Wolff Academy','2015-07-13',32.98,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,2,2),(20,'Wolff Academy','2015-07-09',56.34,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,2,2),(21,'Heavy Duty Linen Computer','2015-06-10',78.65,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,4,NULL),(22,'Lightweight Cotton Hat','2015-06-16',32.93,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,3,NULL),(23,'Durable Granite Bottle','2015-05-07',67.66,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,2,NULL),(24,'Wolff Academy','2015-06-06',93.84,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,2,2),(25,'Amex','2015-07-30',66.66,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,2,3),(26,'Amex','2015-05-30',87.80,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,2,11),(27,'Wolff Academy','2015-05-23',26.18,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,2,2),(28,'Incredible Linen Bag','2015-07-03',88.29,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,5,NULL),(29,'Wolff Academy','2015-05-01',21.33,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,2,2),(30,'Wolff Academy','2015-06-21',44.63,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,2,2),(31,'Rustic Bronze Shirt','2015-05-30',25.50,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,1,NULL),(32,'Awesome Iron Plate','2015-08-01',11.99,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,2,NULL),(33,'Fantastic Bronze Shirt','2015-05-06',9.44,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,1,NULL),(34,'Wolff Academy','2015-08-23',93.38,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,2,2),(35,'Sleek Leather Lamp','2015-08-01',58.82,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,3,NULL),(36,'Heavy Duty Marble Keyboard','2015-06-19',40.90,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,1,NULL),(37,'Enormous Granite Plate','2015-09-21',61.38,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,2,NULL),(38,'Durable Granite Gloves','2015-05-06',2.53,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,5,NULL),(39,'Wolff Academy','2015-07-17',37.22,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,2,2),(40,'Small Iron Bench','2015-08-23',0.02,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,5,NULL),(41,'Wolff Academy','2015-08-16',49.68,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,2,2),(42,'Mediocre Concrete Shoes','2015-09-09',65.38,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,3,NULL),(43,'Wolff Academy','2015-08-28',60.20,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,2,2),(44,'Lightweight Cotton Coat','2015-06-05',81.35,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,1,NULL),(45,'Small Bronze Computer','2015-08-26',99.14,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,3,NULL),(46,'Mediocre Leather Computer','2015-08-09',25.49,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,1,NULL),(47,'Fantastic Linen Table','2015-07-15',82.50,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,2,NULL),(48,'Wolff Academy','2015-06-21',16.55,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,2,2),(49,'Sleek Iron Bench','2015-07-23',42.06,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,1,NULL),(50,'Wolff Academy','2015-08-16',27.10,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,2,2),(51,'Wolff Academy','2015-05-09',76.31,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,2,2),(52,'Fantastic Leather Watch','2015-06-10',83.02,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,1,NULL),(53,'Small Wooden Chair','2015-05-28',59.81,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,5,NULL),(54,'Amex','2015-09-21',20.73,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,2,4),(55,'Synergistic Steel Car','2015-07-16',64.06,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,2,NULL),(56,'Aerodynamic Granite Bottle','2015-05-08',20.75,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,3,NULL),(57,'Fantastic Wool Coat','2015-06-27',68.48,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,5,NULL),(58,'Awesome Copper Plate','2015-07-06',95.81,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,2,NULL),(59,'Wolff Academy','2015-06-21',8.17,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,2,2),(60,'Wolff Academy','2015-09-22',97.93,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,2,2),(61,'Heavy Duty Linen Wallet','2015-06-30',90.99,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,4,NULL),(62,'Amex','2015-08-24',52.32,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,2,1),(63,'Wolff Academy','2015-05-20',55.66,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,2,2),(64,'Practical Aluminum Bench','2015-06-23',64.40,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,1,NULL),(65,'Fantastic Steel Pants','2015-07-27',73.46,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,2,NULL),(66,'Wolff Academy','2015-09-17',33.99,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,2,2),(67,'Durable Bronze Hat','2015-05-21',20.78,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,5,NULL),(68,'Awesome Steel Keyboard','2015-08-09',43.78,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,5,NULL),(69,'Awesome Marble Bench','2015-05-11',98.68,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,5,NULL),(70,'Wolff Academy','2015-06-09',26.96,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,2,2),(71,'Sleek Paper Knife','2015-06-29',47.94,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,1,NULL),(72,'Heavy Duty Linen Chair','2015-05-24',9.36,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,4,NULL),(73,'Amex','2015-06-09',19.99,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,2,11),(74,'Lightweight Plastic Coat','2015-09-21',49.44,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,4,NULL),(75,'Wolff Academy','2015-09-23',76.71,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,2,2),(76,'Wolff Academy','2015-07-19',54.20,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,2,2),(77,'Synergistic Leather Knife','2015-06-07',20.50,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,4,NULL),(78,'Heavy Duty Cotton Shoes','2015-06-07',85.32,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,3,NULL),(79,'Rustic Granite Bottle','2015-07-23',7.58,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,1,NULL),(80,'Mediocre Aluminum Coat','2015-07-15',6.56,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,2,NULL),(81,'Wolff Academy','2015-08-08',17.91,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,2,2),(82,'Ergonomic Aluminum Wallet','2015-07-12',65.76,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,1,NULL),(83,'Wolff Academy','2015-07-04',60.97,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,2,2),(84,'Amex','2015-08-08',32.67,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,2,3),(85,'Incredible Marble Plate','2015-09-26',37.77,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,4,NULL),(86,'Incredible Steel Knife','2015-08-28',27.24,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,2,NULL),(87,'Small Paper Table','2015-05-17',95.56,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,1,NULL),(88,'Mediocre Copper Table','2015-08-25',62.37,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,2,NULL),(89,'Rustic Marble Lamp','2015-06-30',97.99,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,3,NULL),(90,'Enormous Plastic Keyboard','2015-05-26',65.51,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,5,NULL),(91,'Heavy Duty Paper Pants','2015-08-04',23.49,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,3,NULL),(92,'Small Wooden Keyboard','2015-06-23',9.81,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,4,NULL),(93,'Heavy Duty Bronze Clock','2015-06-05',58.44,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,2,NULL),(94,'Amex','2015-08-27',19.02,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,2,1),(95,'Amex','2015-08-01',53.94,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,2,3),(96,'Wolff Academy','2015-09-21',21.87,'2015-09-04 17:29:54','2015-09-04 17:29:54',NULL,2,2),(97,'Rustic Paper Coat','2015-08-06',79.07,'2015-09-04 17:29:55','2015-09-04 17:29:55',NULL,3,NULL),(98,'Wolff Academy','2015-09-23',78.62,'2015-09-04 17:29:55','2015-09-04 17:29:55',NULL,2,2),(99,'Heavy Duty Concrete Car','2015-05-04',60.03,'2015-09-04 17:29:55','2015-09-04 17:29:55',NULL,2,NULL),(100,'Amex','2015-06-06',73.83,'2015-09-04 17:29:55','2015-09-04 17:29:55',NULL,2,11),(101,'Shea Moisture','2015-09-04',55.95,'2015-09-05 01:40:46','2015-09-05 01:40:46',NULL,1,NULL),(102,'Emergency','2015-09-25',328.00,'2015-09-26 02:51:58','2015-09-26 02:51:58',NULL,2,NULL),(103,'Amex','2015-11-04',450.00,'2015-11-26 01:56:49','2015-11-26 01:57:28',NULL,2,5),(113,'Avalon','2015-11-01',1526.00,'2015-11-28 05:05:13','2015-11-28 05:50:55',NULL,2,14),(122,'Should Get Warning','2015-11-30',300.00,'2015-12-01 00:05:02','2015-12-01 00:05:02',NULL,1,NULL),(128,'Amex','2015-12-25',3000.00,'2015-12-24 17:15:41','2015-12-26 03:41:37',NULL,2,17),(130,'Amex','2015-12-26',12300.00,'2015-12-25 07:37:31','2015-12-26 02:43:46',NULL,6,17);
/*!40000 ALTER TABLE `spendings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_contributors`
--

DROP TABLE IF EXISTS `user_contributors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_contributors` (
  `user_id` int(11) DEFAULT NULL,
  `contributor_user_id` int(11) DEFAULT NULL,
  UNIQUE KEY `index_user_contributors_on_user_id_and_contributor_user_id` (`user_id`,`contributor_user_id`),
  UNIQUE KEY `index_user_contributors_on_contributor_user_id_and_user_id` (`contributor_user_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_contributors`
--

LOCK TABLES `user_contributors` WRITE;
/*!40000 ALTER TABLE `user_contributors` DISABLE KEYS */;
INSERT INTO `user_contributors` VALUES (2,3),(3,2);
/*!40000 ALTER TABLE `user_contributors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `encrypted_password` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `reset_password_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reset_password_sent_at` datetime DEFAULT NULL,
  `remember_created_at` datetime DEFAULT NULL,
  `sign_in_count` int(11) NOT NULL DEFAULT '0',
  `current_sign_in_at` datetime DEFAULT NULL,
  `last_sign_in_at` datetime DEFAULT NULL,
  `current_sign_in_ip` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_sign_in_ip` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `confirmation_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `confirmed_at` datetime DEFAULT NULL,
  `confirmation_sent_at` datetime DEFAULT NULL,
  `unconfirmed_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `failed_attempts` int(11) NOT NULL DEFAULT '0',
  `unlock_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locked_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_users_on_email` (`email`),
  UNIQUE KEY `index_users_on_username` (`username`),
  UNIQUE KEY `index_users_on_reset_password_token` (`reset_password_token`),
  UNIQUE KEY `index_users_on_confirmation_token` (`confirmation_token`),
  UNIQUE KEY `index_users_on_unlock_token` (`unlock_token`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (2,'Dev','Dev','dev@local.com','dev','$2a$10$MQXBLoTi4vAnoJ/YkzWuDuphjbQ0QqCN5diUUmxiHmCcZ3T9MY9lW','2015-12-17 15:52:55','2016-01-21 01:06:35',NULL,NULL,NULL,4,'2016-01-21 01:06:35','2016-01-20 21:56:26','10.0.2.2','10.0.2.2',NULL,'2016-01-21 01:06:35',NULL,NULL,0,NULL,NULL),(3,'dev2','dev2','dev2@local.com','dev2','$2a$10$uUeDHDYOAySxzf.ow18Yiu7ymkfOIir38mFafyrFWBli4AilOEfBa','2015-12-25 03:50:00','2015-12-25 03:50:00',NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-01-20 20:10:00
